# OneCard
Server and website for project 6.  Modeled after OneCard.
Simon Langowski slangows@purdue.edu
Herrick Yeh yeh29@purdue.edu
